package test;

public class PriviewRandom {
	int mDNumber;
	
	public int getNumber() {
		return mDNumber;
	}
	public void setNumber(int mDNumber) {
		this.mDNumber = mDNumber;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
