package com.sns.dao;

public class Message {

}
