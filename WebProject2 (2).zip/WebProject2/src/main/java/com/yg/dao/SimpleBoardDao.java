package com.yg.dao;

public class SimpleBoardDao {

}
