package com.uj.dto;

public class CommentWriteDto {

}
