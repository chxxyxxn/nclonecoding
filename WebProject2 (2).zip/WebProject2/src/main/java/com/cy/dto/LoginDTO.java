package com.cy.dto;

public class LoginDTO {
	private int member_id;
	private String email_address;
	private String password;
	private String agree1;
	private String agree2;
	private String register;
	private String expire;
	private String membership;
	private String card_number;
	private String card_expire;
	private String name;
	private int year;
	private int month;
	private int day;
	private String agree3;
	private String agree4;
	private String agree5;
	private String agree6;
	private String agree7;
	private String phone_number;
	private String expired_membership;
	private int code_number;
	
	public int getMember_id() {
		return member_id;
	}
	public void setMember_id(int member_id) {
		this.member_id = member_id;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAgree1() {
		return agree1;
	}
	public void setAgree1(String agree1) {
		this.agree1 = agree1;
	}
	public String getAgree2() {
		return agree2;
	}
	public void setAgree2(String agree2) {
		this.agree2 = agree2;
	}
	public String getRegister() {
		return register;
	}
	public void setRegister(String register) {
		this.register = register;
	}
	public String getExpire() {
		return expire;
	}
	public void setExpire(String expire) {
		this.expire = expire;
	}
	public String getMembership() {
		return membership;
	}
	public void setMembership(String membership) {
		this.membership = membership;
	}
	public String getCard_number() {
		return card_number;
	}
	public void setCard_number(String card_number) {
		this.card_number = card_number;
	}
	public String getCard_expire() {
		return card_expire;
	}
	public void setCard_expire(String card_expire) {
		this.card_expire = card_expire;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public String getAgree3() {
		return agree3;
	}
	public void setAgree3(String agree3) {
		this.agree3 = agree3;
	}
	public String getAgree4() {
		return agree4;
	}
	public void setAgree4(String agree4) {
		this.agree4 = agree4;
	}
	public String getAgree5() {
		return agree5;
	}
	public void setAgree5(String agree5) {
		this.agree5 = agree5;
	}
	public String getAgree6() {
		return agree6;
	}
	public void setAgree6(String agree6) {
		this.agree6 = agree6;
	}
	public String getAgree7() {
		return agree7;
	}
	public void setAgree7(String agree7) {
		this.agree7 = agree7;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getExpired_membership() {
		return expired_membership;
	}
	public void setExpired_membership(String expired_membership) {
		this.expired_membership = expired_membership;
	}
	public int getCode_number() {
		return code_number;
	}
	public void setCode_number(int code_number) {
		this.code_number = code_number;
	}
	
}
